"""
Expose version
"""

__version__ = "2.1.1"
VERSION = __version__.split(".")
